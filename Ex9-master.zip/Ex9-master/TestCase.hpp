#include <iostream>
#include <sstream>
using namespace std;
class TestCase {
private:
    string test_name;
    ostream& out;
    u_int passed, failed; //Number of test cases failed / successful
    u_int num_of_tests_taken;
private:
    ostream& test_failure_output_suffix() {
        out << test_name <<": Failure in test #" << num_of_tests_taken << ": ";
        return out;
    }
public:
    TestCase(string test_name, ostream& o) : test_name(test_name),out(o),passed(0),failed(0),num_of_tests_taken(0) {

    }



    template <typename T>
    TestCase& check_equal(const T& t1, const T& t2)  {
        num_of_tests_taken++;
        if(t1 == t2) {
            passed ++;
        } else {
            test_failure_output_suffix() << t1 << " should equal " << t2 << "!" << endl;
            failed ++;
        }
        return *this;
    }




    template <typename T>
    TestCase& check_different(const T& t1, const T& t2) {
        num_of_tests_taken++;
        if(t1 != t2) {
            passed++;
        }
        else {
            test_failure_output_suffix() << t1 << " should not equal " << t2 << "!" << endl;
            failed ++;
        }
        return *this;
    }




    template <typename FUNCTION, typename ARG, typename EXPECT>
    TestCase& check_function(const FUNCTION& f, const ARG& arg, const EXPECT& expected) {
        num_of_tests_taken++;
        try {
            auto result = f(arg);
            if(result == expected) {
                passed++;
                
            } else {
                test_failure_output_suffix() << "Function should return " << expected << " but returned " << result << "!" << endl;
                failed++;
            }
        } catch(...) {
            this->out << "ERROR: Function error." << endl;
            failed++;
        }
        return *this;
    }




    template <typename T>
    TestCase& check_output(const T& t1, const string& expected) {
        num_of_tests_taken++;
        stringstream ss;
        ss << t1;
        if(ss.str() != expected) {
            test_failure_output_suffix() << "string value should be " << expected << " but is " << t1 << endl;
            failed++;
        }
        else {
            passed++;
        }
        return *this;
    }
    TestCase& print() {
        out << test_name << ": " << failed << " failed, " << passed << " passed, " << num_of_tests_taken << " total." << endl;
        return *this;
    }
};
