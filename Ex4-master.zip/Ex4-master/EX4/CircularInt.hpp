#define EXERCISE4_0_CIRCULARINT_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>

class CircularInt{
    public://constructor 
        CircularInt(int min, int max);
        CircularInt(int min , int max , int current);
    //copy  constructor
        CircularInt(const CircularInt &ci);
        
        ////////////////////getters setters
        int getCurrent() const;
        int getmin() const;
        int getmax() const;
        void setCurrent(int);
        
        
        // left shift
        friend std::ostream& operator<<(std::ostream& os, CircularInt const &circ) ;
        //Addition assignment
        CircularInt& operator+=(const int& r);
        //Increment Postfix and  prefix 
        CircularInt& operator++(int);
        
        CircularInt& operator++();
        // החלפת סימן 
        CircularInt& operator-();
        
        friend CircularInt operator+(const CircularInt& a1,const CircularInt& a2);
         // החלפת סימן 
        CircularInt& operator+();
        //sub
        friend CircularInt operator-(const int &c1, const CircularInt &c2);
        //כפל
        CircularInt* operator*=(const int& rhs);
        //חילוק
        friend CircularInt operator/(const int &c1, const CircularInt &c2);
        
        friend CircularInt operator/(const CircularInt &c2,const int &c1);
        
        
        CircularInt* operator/ ( int num);


    private:
        int min,max,current;
};


